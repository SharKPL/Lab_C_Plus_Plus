#pragma once

namespace Allin {
	void vehicle();
	void car();
	void sedan();
	void coupe();
	void print();
}