#include "Coupe.h"
#include <iostream>

using namespace std;

Coupe::Coupe() {

}

Coupe::~Coupe() {

}

void Coupe::Open2Doors(){
	cout << "2 doors open" << endl;
}

void Coupe::Close2Doors(){
	cout << "2 doors close" << endl;
}