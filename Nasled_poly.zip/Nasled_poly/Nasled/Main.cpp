#include "Allin.h"
using namespace Allin;
int main() {
	print();
	return 0;
}