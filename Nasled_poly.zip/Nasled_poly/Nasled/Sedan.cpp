#include "Sedan.h"
#include <iostream>

using namespace std;

Sedan::Sedan() {

};
Sedan::~Sedan() {

};

void Sedan::remove_the_wheels() {
	cout << "remove 4 wheels" << endl;
}

void Sedan::put_on_the_wheels() {
	cout << "put on 4 wheels" << endl;
}