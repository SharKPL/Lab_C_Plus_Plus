#include "Vehicle.h"
#include <iostream>

using namespace std;

Vehicle::Vehicle(){

}

Vehicle::~Vehicle() {

}

void Vehicle::drive() {
	cout << "exalo" << endl;
}