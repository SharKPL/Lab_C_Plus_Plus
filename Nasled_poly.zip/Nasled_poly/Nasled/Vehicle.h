#pragma once


class Vehicle {
protected:

public:
	Vehicle();
	~Vehicle();

	void drive();
};